import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supplier-home',
  templateUrl: './supplier-home.component.html',
  styleUrls: ['./supplier-home.component.css']
})
export class SupplierHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
