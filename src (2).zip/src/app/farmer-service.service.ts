import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { User } from 'src/Beans/User';
import { Crop } from 'src/Beans/Crop';
import { Advertisement } from 'src/Beans/Advertisement';
import { Supplier } from 'src/Beans/Supplier';

export class Response{
  message:string;
  verfId: string;

}


@Injectable({
  providedIn: 'root'
})



export class FarmerServiceService {


  url="http://localhost:8080/farming";
  http: HttpClient;
  router:Router;
  users:User[]=[];
  flagUser:boolean=false;
  crops:Crop[]=[];
  flagCrop:boolean=false;
  postAdd:Advertisement[]=[];
  flagAdvertisement:boolean=false;
  suppliers:Supplier[]=[];
  flagSupplier:boolean=false;
  constructor(http:HttpClient, router:Router) {
    this.http = http;
    this.router=router;
    this.fetchUser();
    console.log(this.users);
    this.fetchProductRequirements();
    console.log(this.crops)
   }


   

  private handleError(error: any): Promise<any> {
    return Promise.reject(error.error || error);
  }

  

  //Farmer Registration 
  addUser(users):Promise<any>{
    window.alert("Registered Successfully");
    return this.http.post(this.url+"/createuser",users)
    .toPromise()
    .then(response => response)
    .catch(this.handleError);
  }


  //Login Farmer
  getValidation(email, password) {
      return this.http.get(this.url+"/login/"+email+"/"+password);
  }

  //View Product Requirements
  fetchProductRequirements(){
    return this.http.get(this.url+"/viewproductrequirements");
  }


 // Forgot Password 
  forgotPassword(data:any){
   this.http.put(this.url+"/forgotpassword/"+data.pan_Id+"/"+data.email+"/"+data.password,null).subscribe((data)=>
    {
      alert("Password Changed Successfully (U):-)")
      this.router.navigate(['/farmerLogin'])
    },(errorU)=>{
      console.log(errorU.error.message)
      alert("Invalid Credentials")
    })
  }

 

  //View User
  fetchUser(){
    return this.http.get(this.url+"/fetchusers");
  }
  // view crops
  cropDetails(){

    return this.http.get(this.url+"/cropDetails");

  }

  //Advertisement Added
  public addPost(formdata:FormData):Observable<any>{

    return this.http.post(this.url+"/addPost",formdata);
  
  }
  // addPost(postAdd):Promise<any>{
  //   window.alert("Advertisement Successfully Added");
  //   return this.http.post(this.url+"/addPost",postAdd)
  //   .toPromise()
  //   .then(response => response)
  //   .catch(this.handleError);
  //   }

  //Supplier Registration
  addSupplier(suppliers):Promise<any>{
    window.alert("Supplier Successfully Added");
    return this.http.post(this.url+"/createsupplier",suppliers)
    .toPromise()
    .then(response => response)
    .catch(this.handleError);
    }
  
  //Supplier Login
  loginSupplier(supplier_Email, supplier_Password) {
    return this.http.get(this.url+"/supplierlogin/"+supplier_Email+"/"+supplier_Password)
  }

}
