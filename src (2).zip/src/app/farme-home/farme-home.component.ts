import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-farme-home',
  templateUrl: './farme-home.component.html',
  styleUrls: ['./farme-home.component.css']
})
export class FarmeHomeComponent implements OnInit {

  constructor() { }
 
  ngOnInit() {
  }

}
