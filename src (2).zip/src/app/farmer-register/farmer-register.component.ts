import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { FarmerServiceService } from '../farmer-service.service';
import { User } from 'src/Beans/User';
@Component({
  selector: 'app-farmer-register',
  templateUrl: './farmer-register.component.html',
  styleUrls: ['./farmer-register.component.css']
})
export class FarmerRegisterComponent implements OnInit {
  
  users:User;
  farmerService : FarmerServiceService;
  userFlag:boolean=false;
  constructor(private router:Router,farmerService : FarmerServiceService) {
    this.farmerService=farmerService;
   }

  signUp(data:any){
    let users=new User(data.user_Id, data.userName, data.pan_Id, data.aadhar_Id, data.contact_No,
      data.email, data.password,data.flag);
   this.farmerService.addUser(users).then(response=>{
   this.router.navigateByUrl('farmerLogin');
   },
   err=>{
     if (err.success != undefined && err.success == false) {
       alert(err.errors);
       }
   });
  }

  ngOnInit() {
  }

}
