import { Component, OnInit } from '@angular/core';
import { FarmerServiceService } from '../farmer-service.service';

@Component({
  selector: 'app-view-users',
  templateUrl: './view-users.component.html',
  styleUrls: ['./view-users.component.css']
})
export class ViewUsersComponent implements OnInit {

  users;
  farmerServ:FarmerServiceService;

  constructor(farmerServ:FarmerServiceService) {
    this.farmerServ=farmerServ;
   }

  ngOnInit() {
    this.farmerServ.fetchUser().subscribe(data=>this.users=data);
  }

}
