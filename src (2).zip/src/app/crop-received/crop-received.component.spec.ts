import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CropReceivedComponent } from './crop-received.component';

describe('CropReceivedComponent', () => {
  let component: CropReceivedComponent;
  let fixture: ComponentFixture<CropReceivedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CropReceivedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CropReceivedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
