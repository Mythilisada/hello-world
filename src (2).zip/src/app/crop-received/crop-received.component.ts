import { Component, OnInit } from '@angular/core';
import { FarmerServiceService } from '../farmer-service.service';

@Component({
  selector: 'app-crop-received',
  templateUrl: './crop-received.component.html',
  styleUrls: ['./crop-received.component.css']
})
export class CropReceivedComponent implements OnInit {
crops;
  constructor(private farmerServ:FarmerServiceService) { }

  ngOnInit() {

    this.farmerServ.cropDetails().subscribe(data => this.crops = data);
  }

}
