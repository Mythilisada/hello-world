export class User{

    user_Id: number;
    userName: string;
    pan_Id: string;
    aadhar_Id: string;
    contact_No:string;
    email: string;
    password:string;
    flag: string;
    
    

    constructor(
        user_Id: number,
        userName: string,
        pan_Id: string,
        aadhar_Id: string,
        contact_No:string,
        email: string,
        password:string,
        flag: string
        )
    {
        this.user_Id = user_Id;
        this.userName = userName;
        this.pan_Id = pan_Id;
        this.aadhar_Id=aadhar_Id;
        this.contact_No=contact_No;
        this.email = email;
        this.password = password;
        this.flag = flag;
        
    }

}