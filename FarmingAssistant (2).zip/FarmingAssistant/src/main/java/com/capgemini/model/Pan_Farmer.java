package com.capgemini.model;
//package com.cap.entities;
//
//public class Pan_Farmer {
//	private int pan_Id;
//	private int supplier_Id;
//	private String flag;
//	
//	
//	public Pan_Farmer(int pan_Id, int supplier_Id, String flag) {
//		super();
//		this.pan_Id = pan_Id;
//		this.supplier_Id = supplier_Id;
//		this.flag = flag;
//	}
//
//
//	public Pan_Farmer() {
//		super();
//	}
//
//
//	public int getPan_Id() {
//		return pan_Id;
//	}
//
//
//	public void setPan_Id(int pan_Id) {
//		this.pan_Id = pan_Id;
//	}
//
//
//	public int getSupplier_Id() {
//		return supplier_Id;
//	}
//
//
//	public void setSupplier_Id(int supplier_Id) {
//		this.supplier_Id = supplier_Id;
//	}
//
//
//	public String getFlag() {
//		return flag;
//	}
//
//
//	public void setFlag(String flag) {
//		this.flag = flag;
//	}
//	
//	
//	
//
//}
