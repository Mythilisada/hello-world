package com.capgemini.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.capgemini.exception.InvalidDetailsException;
import com.capgemini.exception.UserCreationException;
import com.capgemini.model.Advertisement;
import com.capgemini.model.Crop;
import com.capgemini.model.Response;
import com.capgemini.model.Supplier;
import com.capgemini.model.User;
import com.capgemini.service.FarmerServ;
import com.capgemini.service.SupplierServ;

@CrossOrigin(origins = "*") 
@RestController
@RequestMapping("/farming")
public class FarmerController {
	
	@Autowired
	FarmerServ farmerServ;
	
	@Autowired
	SupplierServ supplierServ;
	
	

	//Register Farmer
	@PostMapping("/createuser")
	public User createUserAccount(@RequestBody User userReg){
		return farmerServ.createUserAccount(userReg);
	}
	
	//Login Farmer
	@GetMapping("/login/{email}/{password}")
	public User loginByuserEmail(@PathVariable String email, @PathVariable String password) {
		return farmerServ.loginByuserEmail(email, password);
	}
	
	//Fetch Products Requirements
	@GetMapping("/viewproductrequirements")
	public List<Crop> viewProductRequirements(){
		return farmerServ.viewProductRequirements();
	}
	
	@PutMapping("/forgotpassword/{pan_Id}/{email}/{password}")
	public User forgotPassword(@PathVariable String pan_Id, @PathVariable String email,
			@PathVariable String password) {
		return farmerServ.forgotPassword(pan_Id,email,password);
	}
	
	//Fetch All Users
	@GetMapping("/fetchusers")
	public List<User> viewAllUsers(){
		return farmerServ.viewAllUsers();
	}
	
	//Fetch All Users
		@GetMapping("/cropDetails")
		public List<Crop> viewAllCropDetails(){
			return supplierServ.viewAllCropDetails();
		}
	
	
	
	//Supplier Part
	//Supplier Registration
	@PostMapping("/createsupplier")
	public Supplier createSupplierAccount(@RequestBody Supplier supplierReg){
		return supplierServ.supplierRegistration(supplierReg);
	}
	
	//Supplier Login
	@GetMapping("/supplierlogin/{supplier_Email}/{supplier_Password}")
	public Supplier loginBySupplierEmail(@PathVariable String supplier_Email, @PathVariable String supplier_Password) {
		return supplierServ.loginBySupplierEmail(supplier_Email, supplier_Password);
	}
	
	//Add Advertisement
	@PostMapping(value="/addPost",consumes=MediaType.MULTIPART_FORM_DATA_VALUE)
	public Advertisement addPost(@RequestParam("file") MultipartFile file, @RequestParam("advtment") String advtment) {
		/*Uploading the document*/
	
	   
	    
	    	Advertisement advertisement=supplierServ.addPost(file, advtment);
	    	if(advertisement!=null)
	    	{
	    		return advertisement;
	    	}
	    	else
	    	{
	    		throw new UserCreationException("Document Not uploaded");
	    	}
	    }
	
	@ExceptionHandler(InvalidDetailsException.class)
	public ResponseEntity<Response> usernotfound1(InvalidDetailsException e)
	{
		return new ResponseEntity<>(new Response(e.getMessage()),HttpStatus.OK);
	}		
		
		
}
	
	
	
	

